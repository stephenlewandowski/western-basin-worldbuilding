# The Dent in the Thermos

The shift board had the date—July 17, 2075—under a pale blue strip that meant the overnight handoff was complete. Nadine set her thermos beside it. The dent in the bottom made it rock once, then settle.

She had forty minutes before the rest of the room would want something from her. She read the lake note, then the intake note, then the treatment log. The three times sat within an hour of one another, which was close enough to invite a sentence and too far apart to make one honest. The shift assistant offered: **Conditions stable; no action indicated.** It had learned the tone of their old handoffs. It had not learned why she disliked that sentence.

“That’s confident,” said Luis, easing his shoulder bag under the bench.

“It’s tidy.”

“Those aren’t always the same thing.”

She looked at him over the rim of her mug. Luis had been on the other shift long enough to know when she was about to make a tidy sentence. He put his bag away and took the printed copy of the probe-cleaning list. One of the boxes was empty. The log did not say who had checked it.

Nadine assumed the check had not happened. She set the probe for cleaning and added a note. Then Luis pointed at the damp mark beside the sink. Someone had rinsed the tool and put it back, but left the box blank. Her assumption had made a small gap look like a missing task. She rubbed the heel of her hand over the damp ring, annoyed at herself and at the form, in that order.

The advisory assistant suggested a comparison window and offered to draft the request. She tapped accept. The draft called the measurements “concurrent.” They were not. She changed the word to “nearby in time,” then added that the records covered different intervals. She could have asked the system to phrase it more plainly. She did not trust plainness to mean the same thing to everyone.

At the cabinet, a seal had curled up at one corner. She checked it with her thumbnail, then took the old hand gauge from its hook. The digital display agreed with the gauge; that was all either of them had been asked to do. She wrote both readings in the logbook. The book’s spine was held together with a blue strip of repair tape. Beside it, the screen stacked neat colored tiles and waited for her to declare a status.

The cable technician was due midmorning. The appointment window said ten to noon. Nadine had thought a utility work order meant the technician could enter the same spaces as her crew. At ten-thirty, the technician called from outside the second gate: different badge, different escort, same dry voice. Nadine looked at the work order and found the access note she had not read. She called the right office, waited through two transfers, and found the person who could send an escort. Nobody was rude. Everyone had another screen open.

While she waited, wind came hard across the open water and lifted the corners of two notices from the yard board. She caught them before they slid under the rail. The steel under her palm had the night’s damp on it. Pump vibration moved through the concrete and up the bones of her feet. She could hear the radio hiss and a gull making a complaint she did not have to log.

The technician arrived just before lunch. He examined the curled seal, then the cable end, and said he could replace one today but would have to leave the second for the next visit. Nadine nearly asked why both were not on the same work order. She stopped herself. She did not know what his permit covered. Instead she asked which one he had inspected and wrote down the answer.

“Your handwriting is still better than the tablet,” he said.

“The tablet doesn’t have to fit in a pocket.”

He laughed, signed the access sheet, and took his case back through the gate. It was a good conversation by utility standards: two people had learned what the other person could do, and neither had promised more.

She ate standing by the railing. Her thermos had cooled to the temperature she liked. A bowling message waited on her old phone: the Thursday team had moved lanes and could she bring the shoes from the garage? She had signed up for bowling because for two hours nobody asked her to compare anything. She texted yes, then remembered her mother’s clinic appointment next week sat across her roster. Her partner had stopped asking whether she could trade shifts. That was harder to answer than a direct request.

On the ride home, she replayed the day’s handoff in her head. The teenager needed a clean shirt for a school event. Her partner had put a pan of onions on the stove and left a note that said, “Do not rescue these. They are supposed to be brown.” Nadine set the table, rescued one onion anyway, and was told by the teenager that it tasted better before her help. She accepted the verdict. After dinner she went to the shared garage bay with a child’s bicycle and a box of secondhand parts. The rear brake rubbed. She loosened it, spun the wheel, and waited for the faint metal whisper to stop.

Her partner had made a Sunday plan with two friends and written it on the kitchen slate. Nadine noticed that her name was absent. There might be a reason. The shift roster might change. Nobody had said anything unkind.

She wiped her hands on a rag and opened the schedule. The clinic appointment still sat opposite her work shift. The bowling lane still needed a shoe bag. She left both entries where they were, and the little bicycle stood with its brake cable loose until morning.
