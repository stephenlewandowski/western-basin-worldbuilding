# The Gate Board

Dale liked the gate board because it did not blink at him. It was a length of old treated wood with marks cut into the side, set beside a newer control box whose lid had the same weatherproof coating as the flexible solar skin over his repair shed. The shed roof charged a row of tool batteries whenever the clouds allowed. Today it had allowed enough. His phone called it 2075; the paper calendar on the nail still knew which days belonged to the breakfast crew.

The field entrance had taken water overnight. His left boot sank to the ankle in the gravel before the gravel decided to act like gravel. Dale said something to it. Nobody heard, except maybe the pump.

He had a task: clear the gate before he took the small tractor across to move a stack of tomato stakes. It was not the day to get the big machine out. His wife had put a circle around the village pancake breakfast on the paper calendar, and his nephew had promised to come by after school to help mend a section of fence. Dale wanted the work done before either one of them could point out that it was still there.

The obstruction was a mat of reeds, stalks and a branch caught below the gate. The box on the post showed a late reading. The board showed the water lower than the sensor did. Dale trusted the board, but not enough to drive across. He shut the gate by hand, cleared the debris, and laid a narrow strip of fresh composite over a soft edge where the old one had split. He tapped it with the handle of his shovel. It flexed and held.

The phone on his belt buzzed. Hannah was at the lane entrance. She had asked the day before about checking two collection points along the edge. He had said the gate would be free before eight. It was eight-twelve.

He had not remembered the exact time. In his head, he had told her “after I get the gate open.” In her message, the time was there in black type. Dale did not like being corrected by a thing he had already agreed to. He liked even less having made her wait.

When she came up in her field boots, cooler in one hand and a slim molecular-preservation case in the other, he lifted the gate board out of her way. The case’s status band was green. She still checked the small dial through its clear lid before she set it in the shade of the truck.

“You wrote eight,” she said.

“I can read.”

“I figured. I was just checking whether the gate read it too.”

He let out a laugh despite himself. She was quicker than the people who apologized at length and then asked for something. He showed her the clear track, pointed at the soft strip, and told her which side would hold the truck. That was what the access note was for. The rest of the field was not hers to wander, and she did not ask.

Hannah unpacked a clean container and checked her route card. Dale stayed by the gate. He knew a ditch by sight, knew where an entrance would swallow a tire, knew the little shiver in a gate before a fitting loosened. The sensor’s late mark did not tell him whether the board was wrong. It told him to look twice. He put a note in the paper book and sent the reading onward without choosing between them.

The sample took longer than she had planned because the lid would not seat on the first try. Hannah cleaned the rim, replaced the seal, and wrote down the delay. Dale watched her mark it carefully, not dramatically. He offered her a clean rag. She declined. He held the gate while she carried the cooler through.

“I’ll try to be on time next time,” he said.

“I’ll put ten extra minutes in the plan.”

“That sounds like a system.”

“It’s a pencil.”

After she left, Dale went back to the stakes. He moved the stack with the tractor, one slow trip at a time. The flexible roof had stored enough power to run the shed tools, not enough to make the old battery charger unnecessary. He plugged the charger in anyway. By noon the shed smelled of warm rubber, wet soil and the coffee his wife had poured into a thermos whose lid belonged to another one.

She had made a list for the breakfast: coffee urn, paper napkins, two pans of eggs, and Dale. She wanted to know whether he planned to go early or merely arrive once the work was done. He said the work would be done by then. She looked past him at the gate fitting he had not yet tightened.

“The breakfast starts at nine,” she said.

“I know when it starts.”

“That’s not what I asked.”

He tightened the fitting. He had thought her question was about the calendar. It was about whether she could count on him to be there with the coffee urn. The answer should have been simple. He had already lost an hour to the gate and another to the neatness of his own promise.

They ate lunch from a cooler on the tailgate. She told him the neighbor’s dog had dragged a whole loaf of bread under the porch. Dale said that was a better plan than wasting it on the committee. She said there wasn’t a committee. He took another bite so he would not have to explain the joke.

The breakfast crew was mostly people who had been cooking eggs together for longer than Dale had been old enough to drink their coffee. He brought the urn because he knew how to clean its stubborn spigot and because he had once forgotten the sugar. They still mentioned the sugar. His wife said the softball team had asked if he was coming Sunday afternoon. Dale told her he had not heard from them. She showed him the message sitting unread on his phone. He had meant to answer, then spent a week thinking the question would go away if he gave it room.

“You could say no,” she said.

“I could.”

“You could also say yes.”

He liked this about her: she did not help him invent a third answer. He pulled his glove from behind the truck seat, checked the worn seam at the thumb and decided he could mend it after breakfast. The glove had been in the cab so long that it smelled like the canvas seat cover. He set it beside the calendar instead of putting it back where it would disappear again.

The paper calendar still showed the breakfast circle. The fence section still waited. On the bench beside the door, his slow-pitch glove was drying with the fingers turned open. Dale put the repaired gate pin in the canvas tote and left the spare beside the calendar, where his wife would find it before he did.
