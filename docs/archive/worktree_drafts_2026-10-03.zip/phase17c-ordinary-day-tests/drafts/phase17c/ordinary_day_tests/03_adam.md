# The Lot on Hold

The lot was not rejected. Adam wrote that sentence twice on the whiteboard because the receiving crew had started calling it “the rejected lot.” The distinction mattered to him, even if it did not make the shelf any wider.

The date on the shift terminal read October 6, 2075. Adam set the padded sample carrier under the bench, checked the calibration wafer against the morning schedule, and warmed the photonic reader. Its narrow blue line passed through the sealed jar and returned as a set of comparisons. The instrument could organize what he had measured. It could not tell him whether the receiving specification asked the right question.

He read the specification binder first. The paper tabs were faded, and his marginal note about the customer’s third column had bled through the page. The reader’s glass was clean. His steel pen was not. He wiped both before he touched the jar.

The characterization was complete for the properties listed. The specification was complete for the properties it listed. They did not meet at the one point the buyer had asked about. Adam had placed the lot on internal hold yesterday. This morning he still thought that had been the careful choice.

His supervisor came by with a storage chart folded in half. The upper bay had to be cleared before a different shipment arrived. Adam heard “clear the shelf” and assumed the hold was about to be lifted. His supervisor meant only that the tagged containers needed moving to the other rack. Adam had mistaken a space problem for a decision about the material.

He caught it when he reached for the red status cards. He stopped, checked the record, and asked. The supervisor looked tired, not angry.

“Move the container. Keep the status.”

Adam nodded. “I thought you meant—”

“I know what you thought. Put it on the lower rack. We’ll talk after the other load is in.”

The lower rack was two aisles away and too close to the warm pipes for Adam’s liking. He checked its listed condition, moved the sample to the approved spot, and changed the location in the register. The machine accepted the update. The sign-off remained blank.

At the loading edge, Wendell Kasparek stood beside his truck with a paper docket in one hand and a thermos in the other. The yard’s small autonomous inspection cart had just rolled beneath the trailer, reading the tires and tags at walking pace. Wendell watched it go, then looked toward Adam.

“It says I’m still here,” he said.

“You are still here.”

“Good. Sometimes the paper disagrees.”

Adam checked the booking. Wendell’s pickup window was confirmed; the receiving signature was not ready because the lot had moved. Adam assumed the driver knew that the hold meant no load. Wendell had assumed that the appointment was about the cargo, not the paperwork. Neither assumption was useful. Adam explained only what he could: the lot remained held, the vehicle had a confirmed window, and the receiving desk needed to sign the updated location before anyone could load it.

Wendell turned the docket around and tapped one line. “I can wait twenty minutes. After that, I have a part run.”

Adam wanted to say the form was already with the desk. He did not know whether it was. He walked the paper over himself, then came back with no signature. The clerk had gone to verify which copy carried the new bay number. Wendell glanced at his clock. Adam felt the space problem as a physical thing then: not a column, but a truck idling nowhere, though the engine was off.

The optics reader could compare the sample with its stored reference. Adam could compare the docket with the load. Wendell could compare an hour waited with the next booking. They were not the same kind of comparison. Adam told him the signature was still pending and did not ask him to hold his day open.

Wendell chose to wait until the twenty minutes were up. The clerk returned at minute seventeen with the corrected paper. Wendell checked the tag himself, accepted the docket, and asked Adam whether the next schedule could be confirmed by the end of the week. Adam said he would send a time, not a promise. Wendell said that was better.

Adam finished the afternoon with calibration checks and a note asking the buyer for a narrowly scoped comparison. He placed the specification binder back on the shelf, but left a paper marker at the silent column. He would remember it better than the terminal would. Or so he thought.

After work, he took the bus past patched pavement and the loading bay’s old steel edge. Rail vibration came through the seat. At home, he and Mara tried to rehearse a song for Wednesday’s cover-band practice. The keyboard’s low C stuck. Adam opened the casing, cleaned the contact, and put it back together. Mara waited with her arms folded until he was done.

“You know you could just play around it,” she said.

“It’s a C.”

“It’ll still be a C tomorrow.”

They tried the song again. The key worked twice and stuck on the third press. Adam marked it with a small piece of tape. Their card-night friends had texted to ask who was bringing the lemon cake. He typed that he would, then looked at next Sunday’s shift. He had not yet decided whether to decline the overtime.

Mara played the keyboard while he rinsed the lunch container. She could play around the bad key without looking down. Adam could not. He had learned the song from a printed chord sheet at a friend’s kitchen table years ago, before the band had a name or anyone expected them to show up on time. They had two paid nights a month now, which was just enough to make Wednesday feel like work if he let it. Mara said the next song should have fewer chords. Adam said fewer chords would not fix the key. She said it might fix him.

Their friends were saving toward a little house with room for a practice corner. Adam had started measuring every rent increase against the payment they hoped to afford. He did not tell Mara he had done the arithmetic again. She knew; she had written the numbers on the back of the grocery list and crossed out the version where they stopped seeing people. On the other side of the list she had written three songs for the next paid night and circled the silly one. Adam wanted them to play the new song he had practiced. Mara said they always sounded best when they were laughing by the bridge. He had no useful counterargument.

The sample remained on the lower rack, the hold unchanged. On the kitchen table the keyboard key sat under a little square of tape. Adam left both decisions open until morning.
