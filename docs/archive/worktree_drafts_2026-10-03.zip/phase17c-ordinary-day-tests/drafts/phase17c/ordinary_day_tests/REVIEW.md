# Ordinary-day experiments — review notes

All six pieces remain K creative experiments. The provisional names and personal details are not canon, and no scientific or setting claim is promoted by a character’s belief.

## 01 · Nadine Kowalski

- **Unique notice:** She hears when a shift record has become tidier than the underlying handoff.
- **Alive outside the role:** Yes; bowling, bicycle repair, family meals, and the roster’s effect on her relationship give her a separate life.
- **Strongest scene detail:** Lake wind lifting the notices while pump vibration comes up through wet concrete.
- **Weakest / most expository passage:** The shift assistant’s drafted handoff explains its limitation a little directly.
- **Another test:** Yes.

## 02 · Dale Renner

- **Unique notice:** He reads the gate, gravel, and field edge before trusting a late device reading.
- **Alive outside the role:** Yes; the breakfast urn, softball glove, spouse, and tomato stakes are particular to his day.
- **Strongest scene detail:** The old gate board beside the weathered control box and flexible shed roof.
- **Weakest / most expository passage:** The solar-skin and charging detail could be left more incidental.
- **Another test:** Yes.

## 03 · Adam Szabo

- **Unique notice:** He distinguishes a held lot from a rejected one, while his carefulness makes him slow to clarify an informal request.
- **Alive outside the role:** Yes; the stuck keyboard key, band practice, house plans, and card night continue after work.
- **Strongest scene detail:** Mara plays around the low C while Adam cannot stop repairing it.
- **Weakest / most expository passage:** The photonic reader passage names what the instrument cannot decide in a slightly explanatory voice.
- **Another test:** Yes.

## 04 · Renata Boyd

- **Unique notice:** She notices the distance between a true posted hour and the time her household can actually use.
- **Alive outside the role:** Yes; her daughter’s paper suns, clothing resale, basil, and small jokes carry the viewpoint.
- **Strongest scene detail:** The bus shelter’s shade ending at pavement that flashes white with heat.
- **Weakest / most expository passage:** The route-assistant choice spells out the schedule tradeoff sooner than Renata needs to name it.
- **Another test:** Yes.

## 05 · Hannah Priebe

- **Unique notice:** She pays attention to what changed between visits, including the route, her own effort, and what another person can infer from her note.
- **Alive outside the role:** Yes; the moving roommate, shared ugly bowl, volleyball chat, and remote game with a friend matter on their own.
- **Strongest scene detail:** Reeds rasping in humid air as the cooler lid snaps shut beside the wet gate.
- **Weakest / most expository passage:** The paragraph explaining why she trusts field observation states a tendency that the route already shows.
- **Another test:** Yes.

## 06 · Wendell Kasparek

- **Unique notice:** He reads a schedule as booked time and lost work, while resisting paperwork that could protect him.
- **Alive outside the role:** Yes; the old dog, tomato bed, outboard parts, wife, and son’s message are not appendages to the truck.
- **Strongest scene detail:** The carburetor part in the sugar bowl, followed by Wendell checking none of the springs went into the dishwater.
- **Weakest / most expository passage:** The inspection-cart and optical-reader moment introduces two pieces of technology in quick succession.
- **Another test:** Yes.
