# The Signature Window

Wendell kicked the rear tire once because he had always kicked the rear tire once. Then he checked it properly with the gauge. The dash had already displayed the pressure in clean green numbers, but the gauge did not need a network and had never told him what he wanted to hear.

The docket book said the loading window was six-thirty. The terminal in the cab said the window had moved to seven. The dispatch calendar showed August 2075. Someone had sent the update at 11:48 the night before, when Wendell had been asleep with his old dog at his feet and a crossword folded open on his chest. The truck’s scheduling assistant had accepted the change on his behalf. It had meant well.

He had a delivery to make at the farm yard after this one. If the loading window slipped, he would have to choose which booking to disappoint. He was not interested in choosing before breakfast.

At the gate, an autonomous inspection cart rolled beneath the trailer and read the tags. It stopped at the left wheel for a few seconds, made a small turn, and continued. Wendell watched it the way he watched a new driver back into a dock: politely, with one hand ready in case. The cart passed. The yard attendant waved him through.

The loading office had the correct docket. It did not have the receiving signature. Wendell was familiar with that distinction in theory and tired of it in practice. He parked with the engine off, took his thermos from the cupholder, and waited. Cold morning air came through the open window. Rail vibration rattled a loose coin in the console.

The new window had not been a command. He had read the dispatcher’s message as a requirement because the words “suggested adjustment” appeared beside the time and he knew what happened when he ignored an adjustment. That was his mistake. He did not ask who had approved it. He simply said yes in the little box, then lost the first booking’s space in the day.

He could have called to ask for the old window back. He disliked dealing with offices, and by the time he thought of that, there was no point. He wrote the change in the docket book with a small question mark. The coil-bound pages were soft from two years of grease and coffee rings. His old phone had a cracked corner, but it could still show the message if he wanted to prove what he had read. He did not want to prove it. He wanted the signature.

Adam Szabo came down from the bench area carrying a folder. Wendell knew him as careful, young enough to look bothered when paperwork was wrong and experienced enough not to pretend it was right. Adam explained the material’s status and the updated location. The lot remained held. The truck’s window remained valid. The receiving desk still needed to sign the correction before loading could begin.

“Is it going today?” Wendell asked.

“I don’t know.”

“You don’t know, or nobody’s said?”

“Nobody’s said.”

Adam could have given him a nicer answer. Wendell respected him for not doing it. He told Adam he would wait until the clock reached seven, then he had another delivery to make. If the signature came, he would take the load. If it didn’t, he would go without it and record the reason. He had let other people’s urgency take the whole day before. He was trying to stop doing that, one booking at a time.

The yard’s optical reader flashed the docket code while Wendell held the paper flat. Its blue beam found a crease and asked him to smooth it. He did. The reader took a second look and printed a small receipt. He tucked it into the old docket book without showing surprise. Tools that worked saved time. Tools that needed paper were still tools.

The signature arrived at 6:57. Wendell checked the lot tag against the docket, then signed the loading copy. Adam watched him do it.

“That’s one for the book,” Wendell said.

“Does the book keep score?”

“It keeps everything. That’s the problem.”

By the time he reached the farm yard, he had missed the earlier part of his second booking but not the appointment itself. The replacement fitting sat in a padded crate with a printed tag and two old straps holding it down. He unloaded it and helped the steward slide it to the side. He did not stay to check the gate. That was not his job and Dale had not asked him to.

At home, the tomato bed needed tying back to its stakes. His wife had worked the morning shift at the care home and left a note beside the sink asking him to take the outboard motor parts off the kitchen table before her sister came by. He moved the carburetor pieces to a tray. The table still had an envelope of notices tucked beneath the placemat. He told himself he would sort them after supper.

He had taken the outboard apart on purpose, which was more than he could say for most of the projects on the table. The motor had belonged to his brother-in-law, who had once promised to take him fishing before the season ended and then spent the whole summer fixing the trailer. Wendell had kept the motor anyway. He liked the small certainty of cleaning one part until the old varnish lifted, then laying it on a rag beside the others. The engine might never turn over. That did not make the work a waste.

His wife came through the kitchen in her care-home shoes and kissed the dog’s head. Wendell asked whether her sister was still coming. She said yes, at six. He looked at the carburetor tray and asked whether the table counted as clear. She told him the table had a whole envelope under the placemat and an engine part in the sugar bowl. He had not noticed the sugar bowl. He moved it to the sink, then checked that none of the tiny springs had gone in with the dishes.

The old dog slept against the screen door. Wendell watered the tomatoes and counted the green ones. His wife had left too many seedlings in the bed because she liked the little leaves; Wendell had thinned them twice and been told to stop. He picked one yellowing stem, then left the rest for her to decide. His son had sent a message asking whether he had looked at the offer for the truck. Wendell read it, then checked the day’s bookings. There was still one empty place where the first window should have been.

He began a reply: “I’m not ready.” He saved it as a draft. The tomato twine slipped from his fingers once and he tied it again, leaving the phone on the step beside the unread notices.
