# The Hours on the Glass

The notice behind the glass said the room opened at five. It was accurate. Renata had read it three days ago and built a plan around it anyway.

Her daughter had a paper sun taped to the refrigerator and a question about whether the orange marker counted as red. The shared calendar header read October 2075. Her mother wanted the new cardigan washed before Sunday, though the tag said it would survive the machine. Renata had a shift, a bus transfer, and a bag of secondhand shirts to photograph for the resale page. She had a small patch of open time at the end of the day and, like a fool, had drawn a box around it.

The kitchen window dimmed itself as the late morning brightened. Renata barely glanced up. The building glass had been replaced before she moved in; it changed shade on hot days and made the plants on the sill lean in unpredictable directions. The basil had recovered. Her daughter’s bean plant had not.

“It’s leaning toward the hallway,” her daughter said.

“Maybe it has plans.”

She watered it while her mother folded the cardigan. The old cracked phone on the counter offered two ways to reach work. The automated route assistant preferred the fast bus and a longer walk at the end. Renata preferred the route with a covered stop. She chose that one, then put her physical transit card in the pocket of the bag she had already packed once.

The small inconvenience arrived as a message from the school bus: the pickup point had moved to the next corner while a curb was being repaired. The message was clear. Renata had not left enough time. Her mother could wait on the bench, but she did not like being left alone when the street was busy. Renata asked her daughter to walk her grandmother down and wait until the bus door opened. Her daughter rolled her eyes at the instruction and immediately took her grandmother’s hand.

Renata reached the stop in time to see them go. She did not get to see whether her mother remembered the cardigan. The question followed her onto the bus and stayed there beside the other things she could not check from work.

Her shift was at a counter where a queue formed faster than the line markers could keep up. A coworker had drawn a tiny crown above the “next person” light. Renata had been trying to guess who did it all week. She thought it was Liza, then caught Liza admiring the little crown with an expression too sincere to be guilty. Renata decided to ask later. She liked small mysteries when they did not require anyone to answer quickly.

During break she photographed three shirts against the kitchen’s old gray wall. A woman asked whether the blue one was “office blue or ferry blue.” Renata asked what that meant. The woman sent a picture of her shoes. Renata told her ferry blue and sold the shirt for the price listed. The sale would cover the replacement pot her daughter wanted for the bean plant, if the plant lasted long enough to need one.

At four, Renata checked the opening notice again. It still said five. She had thought the posted time meant she could bring her mother there after work, wait while her mother rested, and still make it home before her daughter’s reading hour. The notice had never promised that. She had read a true sentence and added the rest herself.

The bus was four minutes late and full. A boy stood up without being asked and offered the end seat. Renata thanked him. The bus shelter’s flexible shade kept the sun off the bench, but the pavement beyond it flashed white with heat. She texted her mother that she was coming straight home. Her mother replied with a picture of the cardigan folded into a square and a note: “It is dry. I am not made of glass.”

Renata smiled at the screen and felt foolish for worrying. Then she worried about whether the smile looked dismissive. She put the phone away.

At home, the room was warm but not unbearable. Her daughter sat on the floor, cutting a paper sun into smaller suns. Her mother was on the stoop with a deck of cards and two glasses of water. The glass window had turned a softer gray. Renata moved the basil away from it and found that the soil was dry again.

She filled the watering can. Her mother asked whether the cardigan had shrunk. Renata said no. Her daughter said it was a little shorter, but only in a way that made it look more like a jacket. They argued about this for several minutes. Renata let them win because they were both right in different ways.

She had told herself she would ask her manager for a schedule adjustment this week. It was easier to ask once than twice, but she had already asked once. She opened the message box and typed a sentence. It sounded accusatory. She deleted it and started again with the hours she could actually work.

The message waited unsent while she served supper. The bean plant leaned toward the hallway. The cardigan hung over the chair back, dry and a little short. Renata left the draft open on her phone beside the transit card and went to sit with her mother and daughter on the stoop.
