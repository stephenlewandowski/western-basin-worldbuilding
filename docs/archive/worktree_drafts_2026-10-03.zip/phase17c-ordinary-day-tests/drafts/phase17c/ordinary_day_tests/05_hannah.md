# The Second Visit

At 5:20 the field van was full of things Hannah had already checked and was about to check again. The tablet displayed June 4, 2075, above the route helper’s neat blue arrow. It did not know the access track had a low rut from yesterday’s rain. She touched the cooler latch, the spare battery, the paper custody forms, then the cooler latch once more. The van’s route helper put the first location in a neat blue arrow. It did not know the access track had a low rut from yesterday’s rain.

She had one ordinary task: visit two collection points and get the containers to the handoff window before it closed. She had done the route enough times that the gate latch was more familiar to her than the project name printed on her jacket. The first visit went normally. She cleaned the trap, changed its battery, marked the effort period and date, and packed the labeled container into a compact molecular-preservation case. A green band showed the case was holding temperature. She checked the little dial anyway.

At the second site, the track was wetter than the image on her tablet had suggested. The van could have gone in, probably. Hannah did not like how the tires sank near the edge. She had once driven past a soft spot because the route tool called it passable and spent the rest of the morning wishing she had taken the longer way. She put the van in reverse and wrote down the deviation.

The alternate entrance meant an extra walk and a gate. Dale was at the far end, tightening something near the old board. He had already moved the gate clear enough for her to pass, though the time was later than he had promised. Hannah checked her message. It was eight twelve; he had written eight.

“You’re late,” she said.

“You’re not wrong.”

His answer was so plain she had to stop herself from congratulating him. She carried the case through and left the van on the firm track. Dale showed her where the new strip covered the soft edge. He did not tell her which way the water would go. He told her where not to put a tire. That was useful.

The cooler lid snapped shut in the wet air. Reeds rasped together in a breeze that smelled of warm mud and crushed green stems. Insects made a thin electrical buzz around her ears. She pulled her sleeve over her wrist, checked the label, and lifted the gate until it caught. Dale held it from the other side.

The sample container was damp along one side. Hannah wiped it, checked the seal, and replaced the outer label because the first one had curled. The status band stayed green. Her paper record showed that the visit had taken longer and used a different access track. Her tablet asked whether to mark the route complete. She chose “complete with note.” The route assistant offered to suggest a follow-up visit. It did not mention what would have to move to make room for one.

She assumed the field note would make the difference obvious. Her supervisor had told her before that people read limits differently when they were trying to plan a route or answer a request. Hannah still felt that if she wrote the time, effort and weather clearly, the reader would see what she saw. She added more detail than the box asked for, then noticed she had forgotten to list the spare battery she had used at the first point.

Her phone buzzed with a message from her roommate: the landlord had found a new tenant for the back room; could Hannah clear the shelf by Saturday? The roommate was moving out, and the rent split would change. Hannah was glad for her friend, who had finally found a room near the ceramics studio. Hannah was also annoyed about the shelf. They had shared the lease for just under a year, and she had assumed the apartment would hold still longer than that.

The apartment shelf had become the roommate’s project and, somehow, Hannah’s project too. Three bowls belonged to both of them, and the ugly green one belonged to neither. Hannah wanted to keep it because it held keys without letting them scratch the table. The roommate wanted it because it was the first thing they had bought together. They agreed to decide on Saturday, which was how they decided most things: by scheduling another talk.

Hannah had thought the move would make her feel abandoned. Mostly she felt relief that somebody she cared about had found a place she liked, then guilt that the rent would go up, then irritation at herself for treating three feelings like a queue. She put the ugly bowl on the counter and loaded the dishwasher around it.

She checked the volleyball chat. Tuesday’s game was still on, though someone had invited a person who kept calling every ball “mine.” Hannah wrote a joke, deleted it, and sent a picture of the muddy boot instead. The friend who lived two states away replied with an animated frog. They had a cooperative game scheduled after dinner, and Hannah needed to pick up ice on the way home.

The lab handoff window was still open. A staff member scanned the case and the paper tag, then pointed out the route note she had put under the form clip. Hannah had assumed the clip made it visible. It had covered half the note. She turned the page over, wrote the limitation on the upper line, and handed it back. The receiving person did not interpret anything. They checked the label and signed for the case.

“Could you come back tomorrow?” Hannah asked.

“I can receive another visit,” the person said. “I can’t tell you what it should replace.”

That answer irritated her for six seconds. Then she remembered that she had not asked who would lose a visit if she repeated the route. She wrote the question in her notebook rather than send a request she could not support.

After work she stopped for fuel and a bag of ice. At home, the shared plot was overgrown around the edge. Hannah pulled weeds while she waited for the game to start. Her beans had climbed the string. The tomato plant had produced one pale fruit too early. She moved it into the sun and sent her roommate a photograph of the empty shelf, though the shelf was not empty yet.

The case had reached the handoff. The next visit did not have a place on tomorrow’s route. Hannah left the question in the notebook, beside a list of boxes she would have to carry downstairs.
