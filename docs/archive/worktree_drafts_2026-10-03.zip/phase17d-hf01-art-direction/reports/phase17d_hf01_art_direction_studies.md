# Phase 17D — HF-01 Glass City art-direction studies

**Decision document for HF-01A public hero · Composite Toledo-derived 2075 scenario / K architectural form · No new canon**

## What is being revised

The invention is a second, inhabited roofline over a Toledo-derived working street: branching optical leaves, deep walkable service ribs, replaceable cassettes, an old crane rail and repair cradle, a bounded freight handoff, public rooms, and an exposed break at a property boundary. Retained brick, concrete, loading doors and river-facing work remain legible. These relationships are the common world of all three treatments. The camera, illustration language and dramatic emphasis change; the canopy's service logic does not.

The procedural HF-01 WebP in the separate `temp/phase17d-hf01-glass-city/` worktree succeeds as a spatial blockout: the leaf field, lifted cassette, brick shell and public lane occupy a coherent section. At a glance, however, the high exterior view, wide empty gray pavement, evenly lit materials and silvery glass make the assembly resemble a modest contemporary transit canopy. The suspended rectangular cassette carries more visual weight than the branching roof. Small simplified people explain scale but offer little emotional entry. The river-facing identity disappears into a pale distance. These are depiction problems, not a reason to discard the invention.

The WebP was inspected visually. The prototype SVG could not be displayed by the available image viewer, and local-file browser access was blocked; its function and status here are drawn only from `temp/phase17d-hf01-glass-city/reports/phase17d_hf01_prototype_notes.md`. That prototype worktree was not modified. The accepted [house style](../docs/phase_briefs/phase17d_public_visual_style_guide.md), [HF-01 production plan](../docs/phase_briefs/phase17d_hf01_hf04_production_plan.md), [Phase 17D synthesis](../docs/phase_briefs/phase17d_futurist_atlas_synthesis.md), and [HF-01 concept](phase17d_hero_futurescape_concepts.md) set the claim boundary.

Camera heights and lens equivalents below are **illustration controls**, not surveyed coordinates or dimensions of a real site. All three should be designed for the planned 2400 × 1350 wide delivery and checked as a responsive website crop. Keep the principal canopy shape and repair readable when reduced to a card.

## A — Atmospheric architectural future

**Premise.** A credible street-level architectural concept image just after rain. The viewer can almost feel the damp brick, changing shade and scale of a maintained roof. Its strength is believable inhabitation; its risk is looking too much like a conventional development visualization if the silhouette stays polite.

1. **Camera height:** pedestrian eye height, roughly 1.6 m in scene coordinates. This puts the public route and old loading doors at the viewer's level rather than treating the district as a model.
2. **Lens / field of view:** moderate wide view, roughly 28–32 mm full-frame equivalent. It admits the whole canopy span without bending masonry or stretching the repair crew into spectacle.
3. **Camera angle:** oblique view along the arcade toward its river-facing opening, nearly level with a restrained upward tilt. One roof edge exits the frame, implying a larger system.
4. **Foreground:** a wet crossing, drain, repaired paving and one person entering the shaded lane. A small reflection picks up a leaf's light pattern; pavement no longer consumes half the image.
5. **Midground:** the broad canopy and an active cassette replacement occupy the center. The old wall, public-room door, bounded freight bay and service rib can all be read without diagram labels.
6. **Background / Toledo cue:** a narrow Maumee light gap, loading-yard silhouette and industrial mass beyond the street. These are composite cues, not an identifiable block or claimed sightline.
7. **Canopy silhouette:** overlapping, differently pitched leaf families form a continuous but uneven roofline. A neighboring unconnected bay prevents a seamless glass-city reading.
8. **Focal maintenance action:** a glazier and lift crew guide one suspended cassette toward an open berth while another worker watches the cordoned public route. The lift path stays physically comprehensible.
9. **People and ordinary use:** a resident pauses at a bench, a delivery worker attends an awkward load, and someone crosses toward a public room. Their presence is casual, not staged as future-fashion advertising.
10. **Light direction:** low warm light enters from the distant opening and grazes wet brick; cooler sky illumination passes through patterned leaves. The replacement gap supplies one bright interior accent.
11. **Weather / atmosphere:** post-shower humidity softens distance while nearby seams remain crisp. Drips, puddles and damp air imply weather as a maintenance condition, without theatrical fog.
12. **Material behavior:** brick absorbs rain unevenly, steel edges catch fine light, timber is worn, and patched ground has a different sheen from fresh work. The scene should feel touched.
13. **Glass translucency / optics:** some leaves admit a diffuse view of sky; others carry fine patterned shade and visible edge laminates. No pane should become a uniform opaque metallic plate.
14. **Color relationships:** dark red-brown brick and charcoal steel ground pale green-blue glass; warm amber replacement pieces and river light provide limited contrast. Avoid an all-gray grade.
15. **Depth hierarchy:** near crossing → repair bay and old wall → receding arcade → river-facing haze. Repeated roof ribs and filtered light lead the eye without invented perspective landmarks.
16. **Detail hierarchy:** most finish sits at the removed cassette, workers, attachment shoes and public threshold. Distant leaves simplify, protecting the overall roof shape at small size.
17. **Intentionally omitted:** glowing data graphics, futuristic skyline, hero labels in the image, close inspection of compute rooms and any design detail that suggests certified structure or cooling performance.
18. **Why 2075:** the street's occupied section has changed: a deep optical roof with walkable servicing, selective automated freight and a public room is maintained across old industrial fabric.
19. **Why Toledo / Western Basin-derived:** glass manufacture, brick factory grain, freight, wet Maumee light and a working waterfront relationship organize the view. No real parcel is reconstructed.
20. **What remains K:** canopy geometry, attachment and replacement method, depicted institutions, precise street arrangement and people. The image inherits only conditional adaptation and dependency relationships, not a built-project claim.

## B — Editorial science-fiction Atlas

**Premise.** A sophisticated illustrated opening spread with strong value masses and selective detail. It reads like a possible world held in one image, then invites the reader toward the explanatory inset. Its strength is editorial clarity; its risk is becoming too diagrammatic if architecture and human activity lose atmosphere.

1. **Camera height:** raised slightly above a person's head, about 2.5–3 m in illustrative scene coordinates, as if viewed from an existing step or loading threshold. This reveals the street split without returning to a model-like aerial view.
2. **Lens / field of view:** normal-to-moderate lens character, about 40–50 mm equivalent, with compressed overlap and controlled geometry. Silhouette and value arrangement matter more than photographic breadth.
3. **Camera angle:** diagonal view across the brick façade and along the public lane. The frame is divided by the old wall, branching roof and lit maintenance opening, not a centered one-point vista.
4. **Foreground:** a cropped dark brick pier, wet bench edge and partial passerby create a strong framing shape. The dark mass gives the roof a luminous counterweight.
5. **Midground:** three large pictorial shapes dominate: retained industrial wall, new roof field and the open repair bay. Freight and public-room thresholds are secondary readable pockets.
6. **Background / Toledo cue:** a thin strip of river light, low work-yard forms, pipes and loading rhythm. Atmospheric simplification preserves identity while avoiding an invented landmark portrait.
7. **Canopy silhouette:** leaf clusters are edited into a few unmistakable directional fans, with an intentional gap and one detached replacement leaf. The underlying service-rib arrangement remains clear.
8. **Focal maintenance action:** a suspended leaf and two workers form the image's high-contrast hinge between old crane rail and new berth. The lift is observed, not turned into heroic combat choreography.
9. **People and ordinary use:** one foreground pedestrian, a seated person, the repair pair and a freight worker establish a small social sequence. Their gestures are specific, faces need not be detailed.
10. **Light direction:** a diagonal break of pale sky light cuts through the empty bay onto the ground. The rest is organized in three broad values: dark old fabric, middle-tone work zone, luminous optical roof.
11. **Weather / atmosphere:** rain has just passed; edge bleeding, dry-brush mist and selective reflections describe humidity. Atmosphere is painted, not simulated uniformly across every surface.
12. **Material behavior:** chipped brick, matte structural steel and worn timber receive textured strokes; new manufactured cassette rims have cleaner edges. Aging is selective enough to read at book-spread scale.
13. **Glass translucency / optics:** layered washes show sky, pattern and internal ribs through different panes. Filtered light lands in bounded patches rather than impossible rainbow projections.
14. **Color relationships:** restricted palette of oxblood/umber, slate blue-green, milky glass and one warm amber maintenance accent. Color separates functions and ages, not arbitrary factions.
15. **Depth hierarchy:** dark near framing → active cross-section → flattened repeating leaves → light river slit. Overlap and scale, more than simulated haze, carry depth.
16. **Detail hierarchy:** finish the cassette edge, hands, shoe and public threshold; suggest the rest with confident strokes. The eye should grasp old/new/repair in two seconds.
17. **Intentionally omitted:** dense cable inventory, literal manufacturing labels, photo-real microtexture, extended skyline and explanatory arrows. The separate SVG can carry technical naming.
18. **Why 2075:** an old industrial block has become a layered optical civic interior. Editorial reduction amplifies the new physical organization instead of depicting speculative devices as isolated props.
19. **Why Toledo / Western Basin-derived:** glass and industrial masonry carry the image's main color and mass; damp river-side light, freight and public use give it basin-specific work rather than generic city spectacle.
20. **What remains K:** all precise forms, light effects, worker arrangements, panel types and cross-property continuity. Painterly certainty must not imply verified dimensions, measured performance or a chosen future.

## C — Glasspunk promotional hero

**Premise.** The most arresting public identity image: a massive tilted glass leaf hangs beneath an inhabited canopy that branches over a recognizably industrial Toledo-derived street. The city seems to have learned to repair its own second roofline. Its strength is an immediate silhouette and emotional entry; its risk is exaggerating glass into magic unless joints, crew and infrastructure stay legible.

1. **Camera height:** low from the exposed crossing, around 0.9–1.2 m in scene coordinates. A person in the lane remains an identifiable viewer surrogate; this is not a drone shot.
2. **Lens / field of view:** emphatic but controlled wide angle, around 23–27 mm equivalent. The roof can soar while brick courses, workers and cassette edges retain plausible proportions.
3. **Camera angle:** looking diagonally upward toward the lifted leaf, with the arcade sweeping from the near old wall into distance. Keep the horizon/river opening visible beneath the roof so scale has a ground.
4. **Foreground:** a small wet crossing and a person stepping from open rain into patterned shade; a cordon edge directs the eye upward. Eliminate the prototype's broad empty apron.
5. **Midground:** the suspended cassette, glaziers, vacant berth and thick service rib form one unmistakable event. The old brick cornice and freight bay demonstrate what the new roof must work around.
6. **Background / Toledo cue:** a sliver of bright Maumee-side sky, low industrial yard/freight forms and older masonry receding beneath the arcade. Avoid landmarks that would invent a specific site.
7. **Canopy silhouette:** asymmetric branching fans of tapered leaves span well beyond one building. One open repair aperture and a property-line break make the roof unforgettable but incomplete.
8. **Focal maintenance action:** an old crane rail and visible cradle suspend a single enormous cassette; a glazier on a service rib guides its edge while a ground worker controls the public exclusion zone. The work is ordinary and supervised.
9. **People and ordinary use:** workers remain small against the section but large enough to read as people. A seated resident, the crossing pedestrian and a freight handler show daily use around, not beneath, a frozen spectacle.
10. **Light direction:** storm cloud opens toward the river. Backlight passes through selected leaves, catches thick edges and strikes amber replacement glass; dark brick frames the brightest repair bay.
11. **Weather / atmosphere:** fast-clearing Great Lakes shower, hanging mist and wet surfaces give depth. Rain remains in the exposed gap, making access and partial coverage visible without promising cooling.
12. **Material behavior:** old brick is saturated and uneven, service steel has real mass and scratches, gaskets are dark, timber is worn, and new cassettes carry manufactured edge build-up. Beauty comes from contrast and use.
13. **Glass translucency / optics:** layers transmit sky and shadow differently; some panes are milky or patterned, one older bay is clouded, one replacement is clearer/warmer. Internal ribs and edge connectors remain visible through the glow.
14. **Color relationships:** near-black storm blue and rust-red brick oppose luminous pale jade/cream glazing; a controlled amber panel and warm human-scale room mark the focal action. No nightclub cyan/magenta.
15. **Depth hierarchy:** sharply legible crossing and repair → repeated canopy fans fading toward river light → faint industrial horizon. Strong near/far contrast keeps the image forceful in a wide banner.
16. **Detail hierarchy:** polish the cassette edge, lifting shoe, glazier and first roof fan; simplify distant bays. Keep the event and silhouette inside the center crop, with one quieter side for responsive title placement.
17. **Intentionally omitted:** flying traffic, illuminated circuit traces, giant holograms, iconic fantasy skyline, fully enclosed crystal dome, unrelated advanced devices and baked-in editorial text. The architecture carries the fiction.
18. **Why 2075:** an old street now has a second working, replaceable optical roofline spanning multiple inherited structures; maintenance, freight and public occupation have adapted to it.
19. **Why Toledo / Western Basin-derived:** the glassmaking identity is manifested as material craft rather than a slogan, while Maumee light, rain, brick industrial shells and freight preserve the region's working texture.
20. **What remains K:** the entire arcade, its geometry, optical treatment, crane reuse, operating arrangement and social scene. The image does not certify structural suitability, bird safety, heat benefit, affordability or adoption.

## Canopy form: five restrained refinements

These adjustments sharpen an existing invention. Each must survive a silhouette or section check and earn its place through construction, access or replacement logic.

| Refinement | Functional reason and visual payoff | Guardrail |
| --- | --- | --- |
| **Directional leaf families** | Taper a few cassette types and vary their pitch around shade/daylight tasks. Branching groups make the roof identifiable from afar and create changing patches of filtered light. | No literal flower petals or decorative random tilts; every leaf returns to a support and service route. |
| **Thick cassette edge** | Give the replaceable panel a readable laminated rim with separate mechanical, optical-data and electrical zones. Its thickness makes manufacture and change-out visible. | Do not imply the glazing itself supplies unlimited energy or carries all services without external plant. |
| **Repeatable attachment shoes** | Show the same stout shoe on installed bays, the suspended cassette and the empty berth. Repetition tells the viewer that replacement is a designed routine. | Keep joints schematic; do not depict them as verified load paths or safe lifting instructions. |
| **Walkable service ribs and old rail** | Make the deep rib a continuous maintenance route, with the repurposed crane rail visibly serving the cradle rather than decorating the skyline. | Do not erase fall protection, access limits or the need to close a public zone during work. |
| **Generations of panels** | Mix clear, patterned, clouded and one differently colored replacement pane. Unequal age shows weathering, standards drift and selective repair at a glance. | Differences must remain manufactured and functional, not stained-glass ornament or proof of optical performance. |

The recognition test is simple: in a black silhouette, the roof should read as a branching, inhabited second roofline; in a section, one leaf should show a serviceable edge, shoe and worker route. If either test fails, adding more gadgets will not help.

## Recommendation: C for the revised HF-01A public hero

Choose **C — Glasspunk promotional hero** as the visual-production direction. It has the strongest single-frame proposition: retained Toledo-derived brick under an enormous branching optical roof, interrupted by a human-guided panel replacement. The low camera and storm-break backlight give public impact and banner readability; the leaf edge, crane, service rib and cordon keep convergence and maintenance visible. Glass behaves as manufactured, aging material. The Maumee-facing light and working freight fabric make the image regional without inventing a real site. This is a recommendation for how to depict HF-01, not a ranking of scenario futures or a canon decision.

Treatment A is the credibility benchmark for materials and occupation; B is the editing benchmark for value and selective detail. Neither should dilute C into a neutral compromise. Before any full-resolution render, review one small composition study in the planned wide aspect ratio: at card size, can a viewer read **glass canopy, old brick, suspended repair leaf and ordinary street** without a caption? Then check the same frame for a plausible lifting path, differentiated panes and a believable river-facing depth. If those fail, revise the composition and light rather than adding devices.

## Compact illustration brief for C

**Use the procedural HF-01 WebP as a structural reference, not as the final camera or finish.** Build a wide public hero from a low, diagonal street view after a Great Lakes shower. A broad branching canopy of translucent, patterned glass leaves becomes a second roofline above retained brick factory shells. A large replaceable leaf hangs from an old crane rail beside an open berth; glaziers on the walkable service rib and a ground worker manage the lift and cordon. A resident enters patterned shade; public room, freight handoff and a disconnected neighboring bay remain visible. Storm clouds part toward a narrow Maumee-side light gap. Dark wet brick and steel frame pale glass, one warm replacement panel and ordinary people.

- **MUST PRESERVE:** branching optical arcade, old/new joints, cassette replacement, service access, separate interfaces, freight/public use, property discontinuity and composite Toledo-derived status.
- **MUST STRENGTHEN:** canopy silhouette, scale, transmission through glass, warm/cool light, layered material age, river-facing depth and human focal action at banner size.
- **MAY INTERPRET:** exact leaf taper, camera and crop, storm-break timing, manufactured pane pattern, surface wear and selective illustrated/composited finish, provided function remains readable.
- **MUST NOT ADD:** neon cyberpunk, flying cars, holograms, fantasy skyline, seamless glass dome, magical energy effects, unbounded automation or decorative technology.
- **MUST NOT CLAIM:** a mapped block, measured geometry, validated engineering, photonic or cooling performance, bird safety, affordability, universal access, completed citywide adoption, a real project or new canon.

The public caption should read **“Composite Toledo-derived 2075 scenario / K architectural form.”** Carry E/S/K explanation and interface labels in page copy and the later supporting section, not across the hero image. This document requests no render or site change; human review selects the direction before production continues.
