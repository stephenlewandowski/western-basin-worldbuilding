# HF-01A — one-round image-generation handoff

**Accepted direction: C — Glasspunk Promotional Hero.** Generate three composition studies of the **same** composite Toledo-derived 2075 street and optical-canopy invention. Use the existing procedural HF-01 image as a structural reference, not as the camera, finish, or approved public image. [The accepted art-direction study](phase17d_hf01_art_direction_studies.md) governs form, atmosphere, and claims. A remains the material/inhabitation benchmark; B remains the editorial-composition benchmark. Compare C1–C3 as wide website-hero candidates, with no added worldbuilding premise.

## C1 — canopy dominant

- **Crop / composition:** Wide 16:9, low diagonal view; the branching optical roof owns roughly the upper two-thirds. A short wet crossing anchors the bottom rather than an empty paved apron.
- **Focal hierarchy:** First the asymmetric leaf silhouette, then the lifted cassette and open berth, then the public street. The roof must read at thumbnail size before its details do.
- **Camera relationship:** From an exposed crossing at pedestrian-adjacent height, aimed upward along the arcade; keep enough ground and horizon to show that the canopy serves a street.
- **Canopy placement:** Fans sweep from a near old-wall attachment across the frame and continue beyond it. Keep one repair aperture and an unconnected neighboring bay visible.
- **Suspended cassette placement:** Slightly right of center against a darker roof opening; its thick rim, crane connection and matching empty berth remain readable without becoming a giant blank rectangle.
- **Old brick placement:** Wet industrial façade and cornice form the lower-left weight beneath new ribs, revealing old/new joints and loading doors.
- **River / freight cue:** A narrow Maumee-side light gap and low yard/freight forms recede under the far canopy edge; no named site or landmark.
- **People:** Small glaziers at the berth, a ground worker at the cordon, a crossing resident and a freight handler provide scale and ordinary use.
- **Storm-break lighting:** Cold storm mass above; warm opening toward the river backlights selected translucent leaves and one differently aged replacement pane. Filtered light reaches wet ground.
- **Responsive negative space:** Reserve a quieter cloud or dark-wall area at upper left for optional site copy; keep the silhouette, cassette and workers inside a central crop.

**Tests whether:** the canopy alone can become a memorable Glass Basin emblem without losing its service logic.

## C2 — human repair dominant

- **Crop / composition:** Wide 16:9, closer to the maintenance bay. The suspended leaf, guiding glazier and empty socket make a strong triangular composition; the roof still spans beyond the repair.
- **Focal hierarchy:** First the human-guided replacement, then the leaf field and old rail, then public/freight activity. Hands, attachment shoes and the lift path receive the sharpest detail.
- **Camera relationship:** Low view from just outside the cordon, looking obliquely up at the service rib rather than directly beneath the load. The viewer stands in the ordinary public realm.
- **Canopy placement:** Layered leaf families frame the upper edge and recede into depth; their walkable rib visibly connects the work position to the retained building.
- **Suspended cassette placement:** Near center-left, separated from the berth by a legible gap. Show a repeatable shoe on the panel and the same interface in the vacant bay.
- **Old brick placement:** A broad, rain-dark factory wall at right carries the legacy rail and frames the lit repair opening; loading and public-room thresholds remain identifiable.
- **River / freight cue:** Through the lane behind the workers, retain a sliver of river-facing light and one bounded freight handoff with a worker, not a parade of vehicles.
- **People:** One glazier guides the edge, one worker supervises below, a passerby follows the cordon and someone waits near the public room. No lone superhero pose.
- **Storm-break lighting:** Backlight catches the cassette's layered edge and damp steel; a warm patch on brick gives the crew separation from the cool post-rain arcade.
- **Responsive negative space:** Keep a relatively quiet dark-brick zone toward the upper right for copy; the complete repair action must survive a narrower center crop.

**Tests whether:** a specific maintenance act can supply the emotional center while still selling the scale and novelty of the canopy.

## C3 — Toledo / street dominant

- **Crop / composition:** Wide 16:9, street-level view down a retained industrial block. Brick, wet public route and freight frontage lead toward a canopy that becomes increasingly extensive overhead.
- **Focal hierarchy:** First the transformed Toledo-derived street, then the branching roof, then the cassette change-out. The place must remain distinctive even if the repair is seen second.
- **Camera relationship:** Pedestrian-height view along the street, nearly level with a modest upward bias. A resident's path carries the eye from exposed rain into patterned shade.
- **Canopy placement:** Begin above old brick at left and branch diagonally across the upper frame; reveal roof depth and a property-line break rather than a seamless glass dome.
- **Suspended cassette placement:** In the midground near the center, silhouetted against an open berth and bright gap; large enough to identify as a replacement, small enough to leave room for street life.
- **Old brick placement:** Retained factory wall, cornice, repaired windows and loading rhythm occupy the left third. The new service rib visibly meets but does not erase them.
- **River / freight cue:** End the perspective with a thin Maumee-side sky/yard opening, low industrial forms and a conventional freight movement; no surveyed sightline.
- **People:** A crossing resident, seated person, glazier, cordon worker and attended freight task distribute daily use across public and work zones.
- **Storm-break lighting:** Light opens at the far river-facing end, grazing wet brick and threading through mixed glass generations; near street remains storm-cool and tactile.
- **Responsive negative space:** Leave a quiet upper-left area of dark brick or storm sky for optional copy, while keeping roof, cassette and river opening within a central crop.

**Tests whether:** the image can announce *Toledo's Glass City becoming a lived 2075 place*, rather than an impressive isolated structure.

## Shared constraints for all three

- **MUST PRESERVE:** One branching optical arcade above retained industrial shells; old/new joints, public route, bounded freight handoff, property discontinuity, old crane rail, human-guided cassette replacement, service access, and composite Toledo-derived status.
- **MUST STRENGTHEN:** Banner-scale roof silhouette; credible translucent/patterned glass; wet, aged brick and steel; scale contrast; river-facing depth; worker legibility; and differentiated public, repair and freight activity.
- **MAY INTERPRET:** Exact crop, leaf taper, storm-break timing, pane pattern, surface wear, and controlled illustration/compositing finish, while maintaining the same functional arrangement and plausible lifting relationship.
- **MUST NOT ADD:** Neon cyberpunk, flying cars, holograms, fantasy skyline, magical optics/energy, seamless crystalline dome, decorative gadgets, autonomous repair without workers, or baked-in titles/callouts.
- **MUST NOT CLAIM:** A real parcel or sightline, measured geometry, validated structure/lift, quantified optical or cooling performance, bird safety, affordability, universal access, citywide adoption, built project, or new canon. Public caption: **“Composite Toledo-derived 2075 scenario / K architectural form.”**

**Accepted canopy refinements in every variant:** (1) directional leaf families; (2) thick cassette edges with distinct mechanical and service zones; (3) repeatable attachment shoes on installed, lifted and empty bays; (4) walkable service ribs tied to the legacy rail and repair cradle; (5) visibly different panel generations, including weathered and replacement glass. Every refinement must clarify shade, access, interface or replacement function; none is ornament.

**Round review:** compare the three at full size, website width and small-card crop. Select a composition only after the canopy, old brick, suspended repair and ordinary street are readable together. This handoff authorizes no rendering, site update, status change, HF-04 work, commit or push.
