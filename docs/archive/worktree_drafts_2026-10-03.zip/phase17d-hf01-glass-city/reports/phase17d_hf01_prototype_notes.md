# HF-01 — Glass City 2075 prototype notes

**Phase 17D / one static prototype / S–K / pending human visual review / no new C**

## Objective and source boundary

Test a Toledo-derived industrial street whose section has acquired an extensive optical arcade. A suspended glass cassette and its maintenance crew carry the scene; old loading bays, ordinary public use, and an unconnected neighboring property remain visible.

Inputs are the accepted [Phase 17D brief](../docs/phase_briefs/phase17d_futurist_atlas_synthesis.md), [HF-01 concept and production recommendation](phase17d_hero_futurescape_concepts.md), and [Phase 17A production findings](phase17a_prototype_findings_and_production_pattern.md). No external imagery, literature, surveyed geometry, or additional scientific phase products were used.

## Reproducible products

- [Hero WebP](../assets/phase17d/hf01/hf01_glass_city_2075.webp): 2160 × 1388 px, including a 92 px caption strip; 181,096 bytes (176.9 KiB).
- [Supporting canopy / old-wall section](../assets/phase17d/hf01/hf01_canopy_section.svg): SVG, 1440 × 900 viewBox, accessible title and description; 7,771 bytes.
- [Hero builder](../src/python/phase17d/build_hf01_glass_city.py): seeded procedural Blender geometry, materials, figures, camera and light; Python/Pillow packages the render as WebP.
- [Inset builder](../src/python/phase17d/build_hf01_canopy_section.py): Python standard library generates and parses the qualitative SVG.

Render environment: Blender 5.2.2 LTS, Cycles, 40 samples with denoising, AgX display transform; Pillow WebP quality 92 / method 6. The compositional model uses arbitrary coordinates, never claimed as measured or validated dimensions. No binary Blender master is saved. A temporary PNG is automatically removed after conversion. Only the WebP and SVG are delivery products.

Rebuild with Python + Pillow and Blender installed:

```text
python src/python/phase17d/build_hf01_glass_city.py --blender "C:/Program Files/Blender Foundation/Blender 5.2/blender.exe"
python src/python/phase17d/build_hf01_canopy_section.py
```

## Convergence, occupation and age

The broad canopy combines patterned optical glazing, articulated shade leaves, deep structural/service ribs, a grated service walkway, mechanical attachment shoes, optical connector tails, and separate electrical connections. A small open control enclosure locates bounded computation in maintained infrastructure. Human-guided lifting and an enclosed freight carrier represent bounded automation. Glazing, shade and service space express thermal-management relationships without claiming cooling performance.

Maintenance is the central activity: a large cassette is suspended from a spreader and old crane rail, behind a temporary barrier, with workers, tool case, cradle and access ladder. The empty roof berth exposes connection points. Amber replacement bays, a patched window, rain-dark pavement repairs, old steel, masonry and worn seating register different ages. Residents rest and walk; a worker is near the public room; a delivery worker attends freight. All people are generic contextual figures.

## S/K and feasibility boundaries

Inherited S relationships are maintained heat adaptation and dependence on energy, labor, staffing, access and governance, through FT-04 and the accepted convergence synthesis. FT-11/12 inspection and compute implementations retain their inherited K status. All new architecture, leaf geometry, attachments, service routes, machinery arrangements, property relationships and human activities are K. No new E or C is created.

The caption states **COMPOSITE TOLEDO-DERIVED 2075 SCENARIO / K ARCHITECTURAL FORM**. The view is not a real future project, mapped parcel, surveyed sightline or engineering proposal. Optical performance, structural loads, fire/egress, bird safety, lifting procedure, drainage, power/cooling capacity, affordability and cross-property agreements remain unresolved. No heat-health benefit, ownership regime or citywide adoption is asserted.

## Visual review and correction limit

One focused correction pass followed the initial render: articulate the optical leaves and service walkway, clarify glass transmission and differing generations, repair pavement overlays and brick projection, add cloud variation, reveal riverfront industry, and improve the inset label spacing. The first draft was overwritten; no duplicate raster is retained. No second correction pass precedes human review.

The image remains closer to a procedural architectural study than a finished illustration. Figures and freight hardware are simplified; weathering is understated and surfaces can read too uniformly. The exterior oblique camera is elevated above a pedestrian's eye level to expose the section. Toledo is evoked through the glassworks, masonry/loading rhythm, river-facing freight and grain infrastructure, rather than an identifiable real block. River light is a background suggestion. Small connector details need full-size inspection, and the supporting section supplies their qualitative explanation. Scene signs are diegetic; no hero callout overlay is used.

| Quality gate | Assessment after the one correction pass |
|---|---|
| 1. Visibly 2075 | Open for review: articulated optical leaves strengthen the silhouette, but the frame still resembles familiar industrial construction. |
| 2. Toledo recognition | Partial: industrial/material and Maumee cues; no identifiable landmark or surveyed block. |
| 3. Technology changes form | Visible in the broad arcade, layered leaves, deep ribs and service walkway. |
| 4. Functional glass | Replacement and patterned surfaces show function; the silver/opaque appearance still needs human judgment. |
| 5. Immediate maintenance | Clear suspended cassette, glaziers, barrier, lifting spreader and access equipment. |
| 6. Old and new layers | Retained brick, loading doors and crane rail contrast with the canopy. |
| 7. Ordinary human use | Seating, pedestrian movement, public-room entrance and freight handoff are present. |
| 8. Compelling without protocol | Pending human review; simplified geometry/materials remain the main limitation. |
| 9. Supporting inset | Legible qualitative explanation, separate from the hero. |
| 10. Avoid cyberpunk / sterile utopia | Muted working district, visible repairs and discontinuity; some surfaces remain too clean. |

Human review must judge whether the revised silhouette is sufficiently ambitious for 2075, whether the Toledo/Glass Basin identity survives without the caption, whether glass feels functional and manufactured, whether replacement reads as ordinary work, and whether the scene is compelling at web-hero size. Review the secondary freight/public-room activities, property discontinuity, old/new layering, and the inset's supporting role. Visual acceptance remains pending.

## Validation and handoff

Both source scripts executed successfully. Blender produced the corrected hero and Pillow opened/decoded the WebP; the SVG parsed with the Python standard library and rendered successfully for visual inspection. The final hero and section were visually inspected. `npm test` passed 22/22 tests in three files; `npm run build` passed. Repository-relative Markdown links passed (108); `git diff --check` and the additional whitespace checks for new text files passed. The new Python sources also parsed successfully. Temporary render/preview files, the generated site build and test cache were removed.

Only these five new prototype files are intended for review. No tracked baseline file or Phase 1–16 artifact was changed. The branch remains based directly on `9fcc67ffda5c9ed6249e8c76efe01bc67660539a`. Stop at human visual review; no commit, push, public-site update or HF-04 production was performed.
