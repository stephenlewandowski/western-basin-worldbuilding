"""HF-01: deterministic Blender concept scene, then an optimized captioned WebP.

Run with ordinary Python + Pillow. Blender 5.2 must be installed or supplied
with --blender. All scene coordinates are compositional K, not surveyed units.
No .blend is saved. The transient render lives in a self-cleaning temp directory.
"""
from __future__ import annotations
import argparse
import math
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / "assets/phase17d/hf01/hf01_glass_city_2075.webp"
SEED = 1701


def scene(render_to, width, samples):
    import bpy
    from mathutils import Vector
    random.seed(SEED)
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)

    def material(name, color, metal=0, rough=.6, glass=0, noise=False):
        m = bpy.data.materials.new(name)
        m.diffuse_color = (*color, 1)
        m.use_nodes = True
        n = m.node_tree.nodes
        bs = n.get('Principled BSDF')
        bs.inputs['Base Color'].default_value = (*color, 1)
        bs.inputs['Metallic'].default_value = metal
        bs.inputs['Roughness'].default_value = rough
        bs.inputs['Transmission Weight'].default_value = glass
        bs.inputs['IOR'].default_value = 1.46
        if noise:
            tex = n.new('ShaderNodeTexNoise'); tex.inputs['Scale'].default_value = 7
            tex.inputs['Detail'].default_value = 4
            ramp = n.new('ShaderNodeValToRGB')
            ramp.color_ramp.elements[0].color = (*[v*.55 for v in color], 1)
            ramp.color_ramp.elements[1].color = (*[min(v*1.4,1) for v in color], 1)
            m.node_tree.links.new(tex.outputs['Fac'], ramp.inputs[0])
            m.node_tree.links.new(ramp.outputs[0], bs.inputs['Base Color'])
            bump = n.new('ShaderNodeBump'); bump.inputs['Strength'].default_value=.27
            bump.inputs['Distance'].default_value=.055
            m.node_tree.links.new(tex.outputs['Fac'], bump.inputs['Height'])
            m.node_tree.links.new(bump.outputs[0], bs.inputs['Normal'])
        return m

    brick=material('old iron-rich brick',(.24,.095,.052),noise=True)
    n=brick.node_tree.nodes; links=brick.node_tree.links
    pos=n.new('ShaderNodeNewGeometry'); sep=n.new('ShaderNodeSeparateXYZ'); comb=n.new('ShaderNodeCombineXYZ')
    links.new(pos.outputs['Position'],sep.inputs[0]); links.new(sep.outputs['Y'],comb.inputs['X']); links.new(sep.outputs['Z'],comb.inputs['Y'])
    bt=n.new('ShaderNodeTexBrick'); bt.inputs['Color1'].default_value=(.29,.11,.062,1); bt.inputs['Color2'].default_value=(.13,.045,.027,1)
    bt.inputs['Mortar'].default_value=(.18,.16,.13,1); bt.inputs['Scale'].default_value=1
    bt.inputs['Mortar Size'].default_value=.012; bt.inputs['Brick Width'].default_value=.48; bt.inputs['Row Height'].default_value=.19
    front=n.new('ShaderNodeCombineXYZ'); links.new(sep.outputs['X'],front.inputs['X']); links.new(sep.outputs['Z'],front.inputs['Y'])
    normal=n.new('ShaderNodeSeparateXYZ'); links.new(pos.outputs['Normal'],normal.inputs[0])
    absolute=n.new('ShaderNodeMath'); absolute.operation='ABSOLUTE'; links.new(normal.outputs['X'],absolute.inputs[0])
    projection=n.new('ShaderNodeMixRGB'); links.new(absolute.outputs[0],projection.inputs[0]); links.new(front.outputs[0],projection.inputs[1]); links.new(comb.outputs[0],projection.inputs[2])
    links.new(projection.outputs[0],bt.inputs['Vector']); links.new(bt.outputs['Color'],n.get('Principled BSDF').inputs['Base Color'])
    bump=n.new('ShaderNodeBump'); bump.inputs['Strength'].default_value=.38; bump.inputs['Distance'].default_value=.045
    links.new(bt.outputs['Fac'],bump.inputs['Height']); links.new(bump.outputs[0],n.get('Principled BSDF').inputs['Normal'])
    steel=material('aged graphite steel',(.10,.14,.14),.65,.39,noise=True)
    rib=material('pale service structure',(.43,.53,.50),.5,.38,noise=True)
    rust=material('oxidized old rail',(.30,.13,.056),.5,.67,noise=True)
    concrete=material('weathered limestone concrete',(.40,.39,.34),rough=.83,noise=True)
    asphalt=material('rain-dark patched pavement',(.14,.18,.18),rough=.48,noise=True)
    timber=material('worn timber',(.32,.20,.09),rough=.72,noise=True)
    dark=material('deep service recess',(.022,.039,.04),rough=.6)
    light=material('clouded older glass',(.61,.77,.72),.03,.27,.58)
    clear=material('replacement optical laminate',(.55,.78,.77),.04,.15,.68)
    milk=material('diffuse fritted glass',(.72,.79,.67),.03,.36,.30)
    amber=material('different-generation amber laminate',(.64,.45,.21),.04,.30,.40)
    stripe=material('ceramic optical pattern',(.63,.72,.66),.2,.38)
    ochre=material('maintenance ochre',(.67,.32,.075),.1,.6)
    blue=material('optical connection blue',(.11,.34,.40),.4,.38)
    cable=material('electrical insulated cable',(.22,.16,.085),.1,.66)
    white=material('warm white lettering',(.80,.81,.73),rough=.85)

    def box(name,loc,dim,mat,bevel=0):
        bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
        ob=bpy.context.object; ob.name=name; ob.dimensions=dim
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        ob.data.materials.append(mat)
        if bevel:
            mod=ob.modifiers.new('manufactured edge','BEVEL'); mod.width=bevel; mod.segments=2
            ob.modifiers.new('weighted face normals','WEIGHTED_NORMAL')
        return ob

    def rod(name,a,b,r,mat,vertices=10):
        a,b=Vector(a),Vector(b); d=b-a
        bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=r, depth=d.length, location=(a+b)/2)
        ob=bpy.context.object; ob.name=name; ob.rotation_euler=d.to_track_quat('Z','Y').to_euler(); ob.data.materials.append(mat)
        return ob

    def sphere(name,loc,scale,mat):
        bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=1,location=loc)
        o=bpy.context.object; o.name=name; o.scale=scale; o.data.materials.append(mat)
        for p in o.data.polygons:p.use_smooth=True
        return o

    def face(name,points,mat):
        mesh=bpy.data.meshes.new(name); mesh.from_pydata(points,[],[list(range(len(points)))]); mesh.update()
        ob=bpy.data.objects.new(name,mesh); bpy.context.collection.objects.link(ob); ob.data.materials.append(mat)
        return ob

    def text_wall(words,y,z,size=.24):
        bpy.ops.object.text_add(location=(-7.22,y,z))
        o=bpy.context.object; o.name=words; o.data.body=words; o.data.size=size; o.data.extrude=.001
        # Text local X points along world Y, local Y along Z, normal toward +X.
        from mathutils import Matrix
        o.rotation_euler=Matrix(((0,0,1),(1,0,0),(0,1,0))).to_euler(); o.data.materials.append(white)

    def person(x,y,coat,pose='walk',turn=0):
        skin=material('skin',random.choice([(.35,.22,.14),(.59,.40,.27),(.24,.15,.10)]),rough=.8)
        cloth=material('work clothing',coat,rough=.9)
        def p(v):
            a,b,z=v; return (x+a*math.cos(turn)-b*math.sin(turn),y+a*math.sin(turn)+b*math.cos(turn),z)
        hip=.95 if pose!='sit' else .62
        sphere('jacket torso',p((0,0,hip+.35)),(.22,.15,.34),cloth)
        sphere('head, contextual figure',p((0,0,hip+.83)),(.115,.12,.15),skin)
        if pose=='work': sphere('safety helmet',p((0,0,hip+.93)),(.145,.15,.085),ochre)
        for s in [-1,1]:
            if pose=='sit': knee=(s*.13,-.39,.52); ankle=(s*.13,-.42,.12)
            else: knee=(s*.12,s*.11,.53); ankle=(s*.13,s*.20,.12)
            rod('trouser upper leg',p((s*.13,0,hip)),p(knee),.092,steel)
            rod('trouser lower leg',p(knee),p(ankle),.072,steel)
            box('work shoe',p((ankle[0],ankle[1]-.045,.07)),(.15,.29,.13),dark,.04)
            elbow=(s*.29,-.13,hip+.30)
            hand=(s*.32,-.26,hip+.65 if pose=='work' else hip+.06)
            rod('sleeve',p((s*.20,0,hip+.57)),p(elbow),.07,cloth)
            rod('forearm',p(elbow),p(hand),.058,cloth); sphere('hand',p(hand),(.055,.06,.065),skin)

    # Wet street, repairs, shallow puddles and a retained pedestrian curb.
    box('street', (1,18,-.18),(85,120,.3),asphalt)
    box('retained sidewalk',(-5.5,15,.035),(4.5,44,.13),concrete,.04)
    for i in range(30):
        x=random.uniform(-1,22); y=random.uniform(-14,43)
        patch=material('asphalt repair',random.choice([(.105,.13,.13),(.19,.22,.21),(.21,.23,.22)]),rough=.45,noise=True)
        box('unequal resurfacing',(x,y,-.032+i*.00001),(random.uniform(.6,3),random.uniform(.8,4),.006),patch)
    wet=material('thin rainwater',(.20,.28,.29),.3,.08)
    for i in range(20):
        x=random.uniform(-7,19); y=random.uniform(-12,39)
        pts=[(x+math.cos(j*math.tau/20)*random.uniform(.7,1.1)*2,y+math.sin(j*math.tau/20)*.5,-.027+i*.00001) for j in range(20)]
        face('rainwater in shallow depression',pts,wet)
    for y in range(-8,37,3):
        box('sidewalk joint',(-5.5,y,.106),(4.4,.024,.007),dark)
    for y in [0,12,24]:
        for j in range(8):box('drain slot',(-3.1,y+j*.10,.01),(.4,.027,.012),dark)

    # Retained masonry shell, concrete piers and the rhythm of loading doors.
    box('Toledo-derived industrial shell',(-12,15,4.65),(8,39,9.3),brick)
    box('concrete foundation',(-7.94,15,.49),(.16,39,.95),concrete)
    for z in [4.45,8.5,9.35]:box('old cornice',(-7.84,15,z),(.35,39,.20),concrete)
    for y in [-4,2,8,14,20,26,32]:
        box('masonry pilaster',(-7.70,y,4.6),(.55,.45,9.4),brick)
        box('rain-stained concrete cap',(-7.62,y,9.4),(.70,.68,.25),concrete)
    for k,y in enumerate([-1,5,11,17,23,29]):
        box('loading opening',(-7.75,y,1.95),(.16,4.55,3.85),dark)
        if k not in [1,3]:
            box('aged steel loading shutter',(-7.63,y,1.83),(.09,3.96,3.45),steel)
            for z in [.4,.75,1.1,1.45,1.8,2.15,2.5,2.85,3.2]:box('shutter fold',(-7.56,y,z),(.065,3.9,.024),rust)
        box('factory glazing',(-7.68,y,6.4),(.13,4.3,2.8),light)
        for dy in [-2.15,-1.075,0,1.075,2.15]:box('window mullion',(-7.57,y+dy,6.4),(.12,.065,2.85),steel)
        for z in [5,5.7,6.4,7.1,7.8]:box('window transom',(-7.56,y,z),(.13,4.3,.065),steel)
        box('stained lintel',(-7.47,y,8),(.45,4.65,.2),concrete)
    # Public room: lit depth, ordinary doors and a staffed access notice.
    box('public room glazing',(-7.48,5,1.7),(.08,4.05,3.2),light)
    for yy in [3.05,4.95,6.95]:box('door frame',(-7.38,yy,1.7),(.13,.07,3.2),rib)
    box('public-service sign',(-7.35,5,3.47),(.16,4.5,.49),blue)
    text_wall('COOL ROOM / PUBLIC ACCESS',3.02,3.34,.20)
    box('opening-hours notice',(-7.30,7.27,1.7),(.04,.45,.60),white)
    for z in [1.55,1.67,1.80]:box('notice text marks',(-7.26,7.27,z),(.02,.32,.018),steel)
    text_wall('GLASS WORKS  /  MAUMEE',-.9,8.75,.37)
    # The crane rail is visibly older than the canopy service structure.
    for z,d in [(6.05,(.50,35,.13)),(6.3,(.13,35,.42)),(6.55,(.5,35,.13))]:box('retained crane I rail',(-5.7,13,z),d,rust)
    for y in [0,8,16,24]:rod('old rail bracket',(-7.8,y,5.6),(-5.7,y,6.1),.13,rust)

    def roof_z(x):return 8.6+1.85*math.sin((x+8)*math.pi/18)
    xs=[-8,-3.5,1,5.5,10]
    for y in [-2,4,10,16,22,28]:
        for a,b in zip(xs,xs[1:]):
            rod('upper structural chord',(a,y,roof_z(a)),(b,y,roof_z(b)),.14,rib)
            rod('deep lower service chord',(a,y,roof_z(a)-.8),(b,y,roof_z(b)-.8),.13,steel)
            for t in [0,.5,1]:
                x=a+(b-a)*t
                rod('open rib diagonal',(x,y,roof_z(x)-.7),(min(x+1.4,b),y,roof_z(min(x+1.4,b))),.055,rib)
        if y in [4,16,28]:
            rod('Y support column',(8.6,y,.1),(8.6,y,6.3),.18,rib)
            for xx in [6.3,10]:rod('Y branch',(8.6,y,6.3),(xx,y,roof_z(xx)-.7),.14,rib)
    for x in xs:
        rod('longitudinal edge rail',(x,-2,roof_z(x)),(x,28,roof_z(x)),.09,rib)
    for k,y in enumerate([-2,4,10,16,22]):
        for j,(a,b) in enumerate(zip(xs,xs[1:])):
            if k==0 and j==2:continue  # Deliberately empty, accessible cassette berth.
            m=amber if (k,j) in [(0,1),(1,2)] else [light,milk,light,clear][(k+j)%4]
            pts=[(a+.1,y+.12,roof_z(a)+.07),(b-.1,y+.12,roof_z(b)+.07),(b-.1,y+5.88,roof_z(b)+.07),(a+.1,y+5.88,roof_z(a)+.07)]
            face('replaceable patterned optical cassette',pts,m)
            for f in range(1,18):
                yy=y+f*6/18
                rod('laminated optical frit',(a+.12,yy,roof_z(a)+.09),(b-.12,yy,roof_z(b)+.09),.012,stripe,6)
            for x in [a+.18,b-.18]:
                for yy in [y+.2,y+5.8]:box('cassette clamp',(x,yy,roof_z(x)+.06),(.25,.22,.15),steel,.015)
    # Correction pass: articulated optical leaves and accessible ribs give the
    # arcade a layered section beyond a conventional glazed industrial shelter.
    for k,y in enumerate([0,8,16,24]):
        pts=[(-7,y,10.0),(-1.7,y-.45,12.5),(4.2,y+2,11.9),(-1.0,y+5,10.7)]
        face('raised faceted optical leaf',pts,milk if k%2 else light)
        for a,b in zip(pts,pts[1:]+pts[:1]):rod('optical leaf edge frame',a,b,.07,rib)
        rod('fold in optical leaf',pts[0],pts[2],.055,steel)
        for t in [.2,.4,.6,.8]:
            a=tuple(pts[0][i]*(1-t)+pts[1][i]*t for i in range(3)); b=tuple(pts[3][i]*(1-t)+pts[2][i]*t for i in range(3))
            rod('optical leaf lamination',a,b,.025,stripe)
        rod('serviceable leaf actuator',(-1.7,y,roof_z(-1.7)),(-1.7,y-.45,12.5),.075,steel)
    for y in [6+i*.45 for i in range(47)]:box('walkable rib grating',(-1.3,y,8.65),(1.1,.055,.09),rib)
    for x in [-1.9,-.7]:
        for y in [6,12,18,24,27]:rod('service walkway railing',(x,y,8.65),(x,y,9.6),.032,rib)
        rod('service walkway handrail',(x,6,9.6),(x,27,9.6),.032,rib)
    # Exposed connectors at the open cassette berth: data, power, mechanical locks.
    for x in [1.2,5.3]:
        box('exposed interface block',(x,-1.8,roof_z(x)-.12),(.48,.40,.32),steel,.025)
        rod('optical connector tail',(x,-1.85,roof_z(x)-.16),(x,-2.0,roof_z(x)-.7),.046,blue)
        rod('electrical connector tail',(x+.12,-1.7,roof_z(x)-.16),(x+.3,-1.7,roof_z(x)-.64),.041,cable)
    # Human-scale removable service case on a deep rib; lid visibly open.
    box('bounded compute/control housing',(-3.3,3.8,7.9),(1.25,.68,.65),steel,.06)
    lid=box('open service housing lid',(-3.3,3.48,8.34),(1.25,.045,.65),rib); lid.rotation_euler[0]=-.6
    for x in [-3.6,-3.3,-3]:rod('service connections',(x,3.45,7.8),(x,3.2,7.42),.033,blue if x==-3.3 else cable)

    # The hero moment: broad cassette suspended in a routine change-out cradle.
    corners=[(.45,-2.0,1.55),(5.1,-2.0,1.55),(5.1,1.65,5.5),(.45,1.65,5.5)]
    face('cassette being replaced',corners,clear)
    for a,b in zip(corners,corners[1:]+corners[:1]):rod('cassette perimeter frame',a,b,.085,rib)
    for t in [i/20 for i in range(1,20)]:
        y=-2+3.65*t; z=1.55+3.95*t
        rod('optical lamination pattern',(.52,y,z+.016),(5.02,y,z+.016),.022,stripe,6)
    rod('laminate center stiffener',(2.77,-2,1.55),(2.77,1.65,5.5),.048,steel)
    for x in [.65,4.9]:
        box('physical quick-lock shoe',(x,-1.9,1.65),(.28,.30,.25),steel,.035)
        rod('service cable on removed panel',(x,-1.91,1.62),(x,-2.23,1.23),.04,blue)
    box('rail trolley',(-5.7,.3,6.75),(.85,1.2,.42),ochre,.06)
    rod('cradle hoist boom',(-5.7,.3,6.85),(3,.3,7.45),.16,steel)
    rod('hoist tension member',(-5.7,.3,7.7),(3,.3,7.45),.065,steel)
    rod('lifting spreader',(.50,.3,6.2),(5,.3,6.2),.095,ochre)
    rod('hoist rope',(2.8,.3,7.45),(2.8,.3,6.2),.028,dark)
    for i in [2,3]:rod('lifting sling',(corners[i][0],.3,6.2),corners[i],.026,dark)
    for x in [.4,5.2]:
        box('service cradle base',(x,-.5,.30),(.55,3.7,.27),ochre,.05)
        for y in [-1.8,.8]:sphere('cradle wheel',(x,y,.16),(.18,.15,.18),dark)
    # Barrier, tools and access platform communicate planned work.
    for x in [-.2,2.6,5.6]:
        for y in [-3.7]:
            box('barrier foot',(x,y,.09),(.60,.42,.16),steel,.04)
            rod('barrier upright',(x,y,.16),(x,y,1.12),.045,ochre)
    for a,b in [(-.2,2.6),(2.6,5.6)]:rod('temporary maintenance barrier',(a,-3.7,1.05),(b,-3.7,1.05),.07,ochre)
    box('tool case',(-.6,-1.6,.28),(.7,.65,.52),blue,.06)
    for y in [1.7,2.8]:rod('access ladder rail',(-1.6,y,.1),(-2.9,y,6.1),.05,steel)
    for z in [i*.4 for i in range(1,15)]:rod('ladder rung',(-1.6-z*1.3/6,1.7,z),(-1.6-z*1.3/6,2.8,z),.035,rib)
    person(5.7,-1.5,(.56,.31,.11),'work',-.4)
    person(-.9,-.6,(.18,.31,.34),'work',-.4)

    # Public seating and ordinary occupation, away from the work enclosure.
    for y in [-5.0,11.5,21]:
        for dy in [-.19,0,.19]:box('worn seating slat',(-5,y+dy,.57),(2.8,.16,.13),timber,.035)
        for x in [-6.45,-3.6]:box('bench support',(x,y,.29),(.13,.65,.58),steel,.03)
        for zz in [.90,1.12]:box('bench backrest',(-5,y+.3,zz),(2.8,.12,.14),timber,.035)
    person(-5.4,-5,(.35,.21,.17),'sit')
    person(-4.3,7.3,(.40,.48,.42),'walk',.3)
    person(-6.9,5.3,(.20,.26,.35),'walk',-1)
    person(6.3,11.0,(.40,.37,.29),'walk',1)
    # Bounded freight automation and human handoff.
    box('separate freight berth',(-5.6,17,.17),(4.5,4.1,.3),concrete,.05)
    box('enclosed freight carrier',(-4.8,17,1.05),(2.6,1.45,1.6),rib,.16)
    box('carrier cargo opening',(-3.47,17,1.15),(.05,1.1,1.1),dark)
    for y in [16.35,17.65]:
        for x in [-5.6,-4.0]:sphere('carrier wheel',(x,y,.38),(.29,.16,.29),dark)
    for y in [16.7,17.3]:box('delivery crate',(-2.6,y,.65),(.75,.5,1.1),timber,.03)
    person(-2.5,18.1,(.49,.33,.17),'work')
    # Visible property break and a less adapted neighbor on the open street.
    box('unadapted neighboring factory',(18,24,3.4),(10,24,6.8),concrete)
    box('neighbor old roof',(18,24,6.85),(10.5,24.5,.25),steel)
    for y in [14,20,26,32]:
        box('neighbor loading door',(12.94,y,1.6),(.14,3.6,3.2),rust)
        box('neighbor window',(12.9,y,4.9),(.12,3.7,1.3),dark)
        for z in [4.3,4.95,5.6]:box('neighbor window bars',(12.81,y,z),(.12,3.8,.055),steel)
    for y in [9,12,15]:rod('boundary fence post',(11,y,.1),(11,y,2),.05,steel)
    for z in [.5,1,1.5,2]:rod('unconnected property boundary',(11,9,z),(11,15,z),.027,steel)
    box('exposed property seam',(10.8,16,.012),(.10,42,.02),rust)
    # River-facing background: freight, low industrial roofs, silos, no future skyline.
    water=material('Maumee river light',(.38,.51,.55),.12,.21)
    box('suggested river beyond district',(0,65,-.02),(140,28,.08),water)
    haze=material('distant industrial grey',(.35,.43,.44),rough=.9)
    for x,y,h,w in [(-19,45,7,10),(-5,82,6,18),(22,83,8,14),(40,73,9,12)]:box('retained industrial background',(x,y,h/2),(w,9,h),haze)
    for x in [4,6,8]:rod('grain silo',(x,85,0),(x,85,10),.94,haze,20)
    for x in [4,15]:rod('port gantry leg',(x,49,0),(x,49,13),.18,haze)
    rod('port gantry beam',(2,49,13),(20,49,13),.22,haze)
    rod('port crane brace',(4,49,7),(13,49,13),.11,haze)
    for x in [-4,1,6]:
        rod('riverfront grain elevator',(x,76,0),(x,76,12),1.9,haze,24)
        sphere('silo dome',(x,76,12),(1.9,1.9,.65),haze)
    for x in [8,12]:box('riverfront freight container',(x,44,1.2),(3.5,5,2.4),rust)
    # Subtle age on the retained wall: pipework, concrete scars and patched glass.
    for y in [2.5,14.5,26.5]:
        rod('aged downpipe',(-7.35,y,.2),(-7.35,y,8.9),.085,rust)
        box('concrete damp stain',(-7.82,y+.15,.5),(.025,.52,.95),steel)
    box('opaque repaired window pane',(-7.50,10.4,6.7),(.025,.95,.58),amber)

    sc=bpy.context.scene
    sc.render.engine='CYCLES'; sc.cycles.samples=samples; sc.cycles.use_denoising=True
    sc.cycles.max_bounces=6; sc.cycles.diffuse_bounces=3; sc.cycles.transmission_bounces=4
    sc.cycles.adaptive_threshold=.045
    sc.world.use_nodes=True
    wn=sc.world.node_tree.nodes; wl=sc.world.node_tree.links
    skycoord=wn.new('ShaderNodeTexCoord'); cloud=wn.new('ShaderNodeTexNoise'); cloud.inputs['Scale'].default_value=3.6; cloud.inputs['Detail'].default_value=5
    wl.new(skycoord.outputs['Normal'],cloud.inputs['Vector'])
    cloudramp=wn.new('ShaderNodeValToRGB'); cloudramp.color_ramp.elements[0].position=.32; cloudramp.color_ramp.elements[0].color=(.27,.39,.51,1)
    cloudramp.color_ramp.elements[1].position=.66; cloudramp.color_ramp.elements[1].color=(.85,.87,.83,1)
    wl.new(cloud.outputs['Fac'],cloudramp.inputs[0]); wl.new(cloudramp.outputs[0],wn['Background'].inputs[0])
    wn['Background'].inputs[1].default_value=.85
    bpy.ops.object.light_add(type='SUN',location=(10,-15,30)); sun=bpy.context.object
    sun.rotation_euler=(.48,-.45,-.42); sun.data.energy=2.2; sun.data.angle=.16; sun.data.color=(1,.91,.77)
    bpy.ops.object.light_add(type='AREA', location=(0,-10,18)); area=bpy.context.object
    area.data.energy=3200; area.data.shape='DISK'; area.data.size=20
    area.rotation_euler=(Vector((0,10,2))-area.location).to_track_quat('-Z','Y').to_euler()
    bpy.ops.object.camera_add(location=(20,-24,5.0)); cam=bpy.context.object
    cam.rotation_euler=(Vector((-.8,12,6.1))-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.lens=32; cam.data.clip_end=400; sc.camera=cam
    sc.render.resolution_x=width; sc.render.resolution_y=round(width*.60); sc.render.resolution_percentage=100
    sc.render.image_settings.file_format='PNG'; sc.render.filepath=str(render_to)
    sc.view_settings.view_transform='AgX'
    sc.render.film_transparent=False
    bpy.ops.render.render(write_still=True)


def deliver(args):
    from PIL import Image, ImageDraw, ImageFont
    blender=args.blender or shutil.which('blender')
    if not blender:
        found=sorted(Path('C:/Program Files/Blender Foundation').glob('Blender */blender.exe'))
        blender=str(found[-1]) if found else None
    if not blender:raise SystemExit('Blender not found: pass --blender PATH')
    OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='hf01_') as temp:
        render=Path(temp)/'scene.png'
        subprocess.run([blender,'--background','--factory-startup','--python',str(Path(__file__).resolve()),'--','--render-to',str(render),'--width',str(args.width),'--samples',str(args.samples)],check=True)
        with Image.open(render) as src:
            src.load(); im=Image.new('RGB',(src.width,src.height+92),(237,237,226)); im.paste(src.convert('RGB'),(0,0))
        d=ImageDraw.Draw(im)
        def font(size):
            for p in ['C:/Windows/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
                if Path(p).exists():return ImageFont.truetype(p,size)
            return ImageFont.load_default(size=size)
        y=im.height-92
        d.line((32,y+1,im.width-32,y+1),fill=(95,113,112),width=2)
        d.text((34,y+16),'HF-01  /  GLASS CITY 2075',font=font(24),fill=(37,57,60))
        d.text((34,y+53),'COMPOSITE TOLEDO-DERIVED 2075 SCENARIO / K ARCHITECTURAL FORM',font=font(17),fill=(60,78,78))
        d.text((im.width-390,y+23),'PROTOTYPE / FOR VISUAL REVIEW',font=font(16),fill=(80,94,92))
        im.save(OUTPUT,'WEBP',quality=92,method=6)
    with Image.open(OUTPUT) as im:im.load(); print(f'HERO PASS: {im.size}, {OUTPUT.stat().st_size:,} bytes, {OUTPUT}')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--blender'); parser.add_argument('--width',type=int,default=2160)
    parser.add_argument('--samples',type=int,default=40); parser.add_argument('--render-to')
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else None)
    if args.render_to:scene(Path(args.render_to),args.width,args.samples)
    else:deliver(args)
